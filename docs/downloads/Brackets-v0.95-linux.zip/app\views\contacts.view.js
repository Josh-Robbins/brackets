import { page } from '/framework/page.js';
export default page({
  id: 'contacts',
  route: '/contacts',
  title: 'Brackets Contacts',
  meta: {
    lang: 'en',
    description: 'Contacts demo showing .data persistence and route-level page composition.'
  },
  seo: {
    changefreq: 'weekly',
    priority: 0.7
  },
  html: '@pages/contacts.html',
  layout: '@layouts/app.html',
  logic: '@logic/contacts.logic',
  data: {
    contacts: '@data/contacts.data'
  }
});
