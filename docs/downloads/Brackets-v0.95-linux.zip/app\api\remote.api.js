export default (({
  async summary({ http }) {
    return http.client('/remote/api').get('summary')
  },

  async status({ http }) {
    return http.client('/remote/api').get('status')
  },

  stream({ http }) {
    return http.client('/remote').read('events/counts')
  }
}));
