import { page } from '/framework/page.js';
export default page({
  id: 'home',
  route: '/',
  title: 'Brackets Home',
  meta: {
    lang: 'en',
    description: 'Brackets demo home page with local data, remote transport, and Datastar-powered interactivity.'
  },
  seo: {
    changefreq: 'daily',
    priority: 1
  },
  html: '@pages/home.html',
  layout: '@layouts/app.html',
  logic: '@logic/home.logic',
  api: {
    remote: '@api/remote.api'
  },
  data: {
    contacts: '@data/contacts.data'
  }
});
