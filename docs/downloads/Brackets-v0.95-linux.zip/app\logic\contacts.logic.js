export default (({
  async mount({ data, state }) {
    const contacts = await data.contacts.list()
    state.set({
      contacts,
      draftName: '',
      draftSource: 'desktop'
    })
  },

  async addContact({ data, state, action }) {
    const form = action.input() ?? {}
    const next = await data.contacts.add(form)
    state.set({
      contacts: next,
      draftName: '',
      draftSource: 'desktop'
    })
  },

  async reload({ data, state }) {
    const contacts = await data.contacts.list()
    state.set({ contacts })
  }
}));
