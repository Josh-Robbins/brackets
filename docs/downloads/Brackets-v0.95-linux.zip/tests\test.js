import test from 'node:test';
import assert from 'node:assert/strict';

test('Brackets starter is present', () => {
  assert.ok(true);
});
